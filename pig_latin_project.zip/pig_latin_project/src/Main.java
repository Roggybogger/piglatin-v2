// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter phrase you want to be translated into Pig Latin: ");
        String phrase = input.nextLine();
        System.out.println(phrase);

        String pigLatinPhrase = pigLatinSentence(phrase);

        System.out.println("Pig Latin translation: " + pigLatinPhrase);
    }

    public static String pigLatinSentence(String s) {
        StringBuilder ans = new StringBuilder();
        int wordStart = 0;

        for (int i = 0; i < s.length(); i++) {

            if (s.charAt(i) == ' ' ) {


               String word = s.substring(wordStart, i);
               wordStart = i + 1;


                //if you are on the last index numbner  substring(workdStart)

                if (!ans.toString().isEmpty()) {
                    ans.append(" ");
                }


                StringBuilder translatedWord = new StringBuilder();
                String vowels = "aeiouy";
                int indexOfFirstVowel = -1;
                String lowerCaseWord = word.toLowerCase();

                for (int j = 0; j < word.length(); j++) {
                    char c = lowerCaseWord.charAt(j);
                    if (vowels.indexOf(c) != -1) {
                        indexOfFirstVowel = j;

                    }
                }

                if (indexOfFirstVowel == 0) {
                    translatedWord.append(word).append("way");
                } else {
                    translatedWord.append(word.substring(indexOfFirstVowel))
                            .append(word.substring(0, indexOfFirstVowel))
                            .append("ay");
                }
                ans.append(translatedWord);


            }
        }
        //End of loop
        String word = s.substring(wordStart);

        if (!ans.toString().isEmpty()) {
            ans.append(" ");
        }


        StringBuilder translatedWord = new StringBuilder();
        String vowels = "aeiouy";
        int indexOfFirstVowel = -1;
        String lowerCaseWord = word.toLowerCase();

        for (int j = 0; j < word.length(); j++) {
            char c = lowerCaseWord.charAt(j);
            if (vowels.indexOf(c) != -1) {
                indexOfFirstVowel = j;

            }
        }

        if (indexOfFirstVowel == 0) {
            translatedWord.append(word).append("way");
        } else {
            translatedWord.append(word.substring(indexOfFirstVowel))
                    .append(word.substring(0, indexOfFirstVowel))
                    .append("ay");
        }
        ans.append(translatedWord);


























        return ans.toString();

    }
}
